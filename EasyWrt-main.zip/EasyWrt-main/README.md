## EasyWrt

#### 基于https://github.com/padavanonly/immortalwrt-mt798x-6.6
#### 设备：小米AX3000T，红米AX6000

```
固件管理ip：192.168.5.1(小米AX3000T) | 192.168.6.1（红米AX6000）
uboot ip：192.168.1.1(小米AX3000T) | 192.168.31.1（红米AX6000）
分区布局：stock layout
用户名：root
密码：为空
```
